class GenericModalForm {
    
    constructor(params) {
        this._form        = document.getElementById('formulario');
        this._mensagem    = new MensagemView(document.getElementById('msg'));
        this._msgModal    = new MensagemView(document.getElementById('msgModal'));
        this._urlEdita    = params.url_edit;
        this._urlRemove   = params.url_remove;
        this._btSalvar    = document.getElementById('btnSalvar');
        this._btAlterar   = document.getElementById('btnAlterar');
        this._modalView   = $('#modal');
    }

    salvar(formId = null) {
        this._oValida = new ValidaForm();

        if (!this._oValida.validaFormulario(formId)) {
            this._msgModal.update(this._oValida.getMensagem(), 'E');
            return false;
        }
        
        let $form = (formId)? $(`#${formId}`) : $('#formulario');
        
        $form.ajaxSubmit({
            async: false,
            success: (response) => {
                if (response.retorno !== 'sucesso') {
                    this._msgModal.update(response.msg, 'E');
                }
                else if (response.retorno === 'sucesso') {
                    this._mensagem.update(response.msg);
                    this._modalView.modal('hide');
                    Grid.reloadGrid();
                }
            },
            error: (request, status, error) => {
                if(request.status === 404) {
                    this._msgModal.update('Página não encontrada.', 'E', 7000);
                }else {
                    window.console.log(request.responseText);
                }
            }
        });

        return false;
    }

    remover() {
        if (confirm('Deseja realmente remover este registro?')) {
            Utils.ajaxPost(this._urlRemove, {id: rowData.id}, (response) => {
                if (response.retorno !== 'sucesso') {
                    this._msgModal.update(response.msg, 'E');
                }
                else if (response.retorno === 'sucesso') {
                    this._mensagem.setMessage(response.msg);
                    Grid.reloadGrid();
                }
            });
        }
    }

    inicializaModal(formId=null) {
        this._form.reset();
        this._form.id.value = '';
        this._msgModal.escondeMensagem();
        
        if(!formId) {
            this._formulario = $('input[required], select[required], textarea[required]');
        }else {
            this._formulario = $(`${formId} input[required], ${formId} select[required], ${formId} textarea[required]`);
        }
        
        $.each(this._formulario, function(){
            $(this).parent().parent().removeClass('has-error').removeClass('has-danger');
        });
    }
    

    loadGrid(options) {
        Grid.load(options);
    }

    pesquisar(e) {

        //       if (e.target.type == "submit") {
        if (!e) {
            Grid.reloadGrid();
        } else if (e.keyCode == 13) {
            Grid.reloadGrid();
        }
    }

}
