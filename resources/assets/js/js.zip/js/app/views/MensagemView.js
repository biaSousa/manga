
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


class MensagemView {
    
    constructor(elemento) {
        
        this._elemento = elemento;
    }
    
    template(model) {
        return model;
    }
    
    /**
     * 
     * @param {type} model
     * @param {type} tipo
     * @returns {undefined}
     */
    update(model, tipo='S', time=null) {        
        this._elemento.innerHTML = model;
        this._elemento.classList.remove('hidden');        
        (tipo === 'E') ? this.changeAlertClass('alert-danger') : this.changeAlertClass('alert-success');
        
        if(tipo == 'S'){
            setTimeout(() => {this.escondeMensagem()}, (time)? time : 7000);
        }
        else if(tipo == 'E' && time){
            setTimeout(() => {this.escondeMensagem()}, time);
        }
        
        $('html, body').animate({scrollTop:0}, 'slow');
    }
    
    mostraMensagem() {
        if(this._elemento) {
            this._elemento.classList.remove('hidden');
        }
    }
    
    escondeMensagem() {
        if(this._elemento) {
            this._elemento.classList.add('hidden');
            this._elemento.innerHTML = '';
        }
    }
    
    changeAlertClass(classe) {
        this._elemento.classList.remove('alert-success');
        this._elemento.classList.remove('alert-danger');
        this._elemento.classList.add(classe);
    }
    
    style(model) {
        this._elemento.css(model);
    }
    
    getElemento() {
        return this._elemento;
    }
    
    
}