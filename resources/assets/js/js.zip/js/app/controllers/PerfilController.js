/**
 * @requires app/model/Ajax.js
 * @requires app/model/Mensagem.js
 * @requires app/views/Snackbar.js
 */
class PerfilController {

    constructor() {
        this._form = document.getElementById('formulario');
        this._salvar = document.getElementById('salvar');
    }

    exibirAlerta(m) {
        let snackbar = new Snackbar();
        snackbar.exibirVerde(m);
    }

    filtrarGrupo(e) {
        //exibe todas as linhas ocultas
        let linhas = document.querySelectorAll('tbody tr');
        for (let i = 0; i < linhas.length; i++) {
            linhas[i].style = '';
        }

        //se não houver nada selecionado então retorna
        if(e.value == '') return;
        
        //oculta as linhas diferentes do grupo selecionado
        linhas = document.querySelectorAll(`tbody tr:not(.${e.value})`);

        for (let i = 0; i < linhas.length; i++) {
            linhas[i].style.display = 'none';
        }
    }

    salvar(e) {
        e.preventDefault();

        Ajax.ajax({
            url: this._form.action,
            method: this._form.method,
            data: this._form.serialize(),
            beforeSend: () => {
                this._salvar.innerHTML = '<i class="glyphicon glyphicon-time"></i> Aguarde';
                this._salvar.disabled = true;
            },
            success: (json) => {
                window.location = `${this._salvar.dataset.url}/${json.perfil}`;
            },
            error: (json) => {
                let snackbar = new Snackbar();
                snackbar.exibirVermelho(json, false);

                this._salvar.innerHTML = '<i class="glyphicon glyphicon-floppy-disk"></i> Salvar';
                this._salvar.disabled = false;
            }
        });
    }
}