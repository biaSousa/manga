class UnidadeController extends GenericModalForm {
    
    constructor(params) {
        super(params);
        
        this._pUnidade = new AutocompleteJS('pUnidade');
        this._pConta   = new AutocompleteJS('pConta');
        
        this._divUnidades   = document.getElementById('divUnidadesAdd');
	this._tableUnidades = document.getElementById('listaUnidades');
	this._divContas     = document.getElementById('divContasAdd');
	this._tableContas   = document.getElementById('listaContas');
        
        this._unidade  = new AutocompleteJS('unidade', (value, element) => {
            if(value) {                
                let index = element.selectedIndex;
                let descricao = element.options[index].textContent;

		let linha = `<tr id="unidade_${index}">
				<td>
				    ${descricao} <a href="#" class="pull-right" onclick="document.getElementById('unidade_${index}').remove()">
				    <i class="glyphicon glyphicon-remove" style="color: #000;"></i></a>
					
				    <input type="hidden" name="unidades[]" value="${value}">
				</td>	
			    </tr>`;

		this._tableUnidades.insertAdjacentHTML('beforeend', linha);
                this._divUnidades.classList.remove('hidden');
                this._unidade.setValue('');
	    }
        });
        
        this._conta    = new AutocompleteJS('conta', (value, element) => {            
            if(value) {                
                let index = element.selectedIndex;
                let descricao = element.options[index].textContent;

		let linha = `<tr id="conta_${index}">
				<td>
				    ${descricao} <a href="#" class="pull-right" onclick="document.getElementById('conta_${index}').remove()">
				    <i class="glyphicon glyphicon-remove" style="color: #000;"></i></a>
					
				    <input type="hidden" name="contas[]" value="${value}">
				</td>	
			    </tr>`;

		this._tableContas.insertAdjacentHTML('beforeend', linha);
                this._divContas.classList.remove('hidden');
                this._conta.setValue('');
	    }
        });
    }
    
    
    abrirModal() {
        this.inicializaModal();
    }
}