class AdminUsuarioController {
    constructor() {
        this._tabela = document.getElementById('grid');
        this._reativar = document.getElementById('reativar');
        this._reativarTooltip = this._reativar.Tooltip;
    }

    criar(e) {
        window.location = `${BASE_URL}${e.dataset.action}`;
    }

    editar(e) {
        let linha = oTable.rows('.selected').data()[0];
        if (linha !== null) {
            window.location = `${e.dataset.action}/${linha.id}`;
        }
        else
            alert('Selecione um item');
        return false;
    }

    excluir(f) {
        if (!confirm('Deseja realmente remover o acesso deste usuário neste sistema?')) {
            return false;
        }

        let linha = oTable.rows('.selected').data()[0];

        if (linha !== null) {
            Ajax.ajax({
                url: `${f.dataset.action}`,
                method: 'post',
                data: { id: linha.id },
                success: function () {
                    oTable.draw();
                },
                error: function (e) {
                    alert(e.message);
                },
            });
        }
        else
            alert('Selecione um item');
    }

    reativar(e) {
        let linha = oTable.rows('.selected').data()[0];

        Ajax.ajax({
            url: `${e.dataset.action}`,
            method: 'post',
            data: { usuario: linha.id },
            success: (e) => {
                alert(e.message);
                this._reativarTooltip.hide();
                oTable.draw();
            },
            error: function (e) {
                alert(e.message);
            }
        });
    }

    pesquisar(e) {
        e.preventDefault();
        oTable.draw();
    }

    //a cada atualização da tabela percorre todas as linhas da tabela e troca números por ícones
    rowCallback(row, data, index) {
        if (data.ativo == 0) {
            row.cells[2].style.textAlign = 'center';
            row.cells[2].innerHTML = '<i class="glyphicon glyphicon-remove-sign" style="color: red" data-cor="red" title="inativo"></i>';
        }
        else {
            row.cells[2].style.textAlign = 'center';
            row.cells[2].innerHTML = '<i class="glyphicon glyphicon-ok-sign" style="color: green" data-cor="green" title="ativo"></i>';
        }
    }

    linhasGridCallback() {

        this._reativar.disabled = true;

        //retorna todos os ícones a sua cor original
        let icones = document.querySelectorAll('td>i[style^="color: white"]');
        for (let i = 0; i < icones.length; i++) {
            icones[i].style.color = icones[i].dataset.cor;
        }

        //deixa branco o ícone selecionado
        if (oTable.rows('.selected').data().length > 0) {
            let linha = oTable.rows('.selected').data()[0];

            let linhaTag = document.getElementById(linha.id);
            let icone = linhaTag.querySelector('i');
            icone.style.color = 'white';

            // se o ícone selecionado estiver desativado então habilita o botão de reativar
            if(linha.ativo === 0) {
                this._reativar.disabled = false;
            }
        }
    }
}