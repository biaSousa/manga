class EditarUsuarioController {
    constructor() {
        this._nome = document.getElementById('nome');
        this._cpf = document.getElementById('cpf');
        this._perfil = document.getElementById('perfil2');
        this._grid = document.getElementById('grid');
        this._form = document.getElementById('form');
        this._unidade = document.getElementById('unidade');

        let mascaraCPF = [/\d/, /\d/, /\d/, '.', /\d/, /\d/, /\d/, '.', /\d/, /\d/, /\d/, '-', /\d/, /\d/];
        this.mascara(this._cpf, mascaraCPF);
    }

    adicionarPerfil() {
        if (!this._perfil.value) return;

        if (this._grid.querySelectorAll(`tbody tr[id="${this._perfil.value}"]`).length > 0) {
            return false;
        }

        oTable.row.add({
            'DT_RowId': this._perfil.value,
            'perfil': this._perfil.options[this._perfil.selectedIndex].text + '<input type="hidden" value="' + this._perfil.value + '" name="perfil[]">'
        }).draw();
    }

    removerPerfil() {
        oTable.rows('.selected').remove().draw();
    }

    salvar(e) {
        e.preventDefault();

        if (this._form.checkValidity() === false) {
            return;
        }

        Ajax.ajax({
            url: this._form.action,
            data: this._form.serialize(),
            method: 'post',
            success: function (e) {
                let snackbar = new Snackbar();
                snackbar.exibirVerde(e);
            },
            error: function (e) {
                let snackbar = new Snackbar();
                snackbar.exibirVermelho(e, false);
            }
        });
    }

    baixarDados() {
        Ajax.ajax({
            url: this._cpf.dataset.url,
            data: {cpf:this._cpf.value},
            success: (e) => {
                this._nome.value = e.servidor;
                this._unidade.value = `${e.sigla ? e.sigla + ' - ' : ''}${e.unidade}`;
            },
            method: 'POST',
            error: function (e) {
                let snackbar = new Snackbar();
                snackbar.exibirVermelho(e, false);
            }
        });
    }

    mascara(e, m) {
        vanillaTextMask.maskInput({
            inputElement: e,
            mask: m,
        });
    }
}