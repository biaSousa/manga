class CriarUsuarioController {
    constructor() {
        this._perfil = document.getElementById('perfil2');
        this._grid = document.getElementById('grid');
        this._form = document.getElementById('form');
        this._nome = document.getElementById('nome');
        this._email = document.getElementById('email');
        this._cpf = document.getElementById('cpf');
        this._unidade = document.getElementById('unidade');
        this._dtNascimento = document.getElementById('dt_nascimento');

        let mascaraCPF = [/\d/, /\d/, /\d/, '.', /\d/, /\d/, /\d/, '.', /\d/, /\d/, /\d/, '-', /\d/, /\d/];
        this.mascara(this._cpf, mascaraCPF);

        let mascaraData = [/\d/, /\d/, '/', /\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/];
        this.mascara(this._dtNascimento, mascaraData);
    }

    adicionarPerfil() {
        if (!this._perfil.value) return;

        if (this._grid.querySelectorAll(`tbody tr[id="${this._perfil.value}"]`).length > 0) {
            return false;
        }

        oTable.row.add({
            'DT_RowId': this._perfil.value,
            'perfil': this._perfil.options[this._perfil.selectedIndex].text + '<input type="hidden" value="' + this._perfil.value + '" name="perfil[]">'
        }).draw();
    }

    baixarDados() {
        this._nome.value = '';
        this._email.value = '';
        this._unidade.value = '';

        Ajax.ajax({
            url: this._cpf.dataset.url,
            data: { cpf: this._cpf.value },
            success: (e) => {
                this._nome.value = e.servidor;
                let sigla = `${e.sigla != null ? e.sigla + ' - ' : ''}`;
                this._unidade.value = `${sigla}${e.unidade ? e.unidade : ''}`;
            },
            method: 'POST',
            error: function (e) {
                let snackbar = new Snackbar();
                snackbar.exibirVermelho(e, false);
            }
        });
    }

    removerPerfil() {
        oTable.rows('.selected').remove().draw();
    }

    salvar(e) {
        e.preventDefault();
        Ajax.ajax({
            url: this._form.action,
            data: this._form.serialize(),
            method: 'post',
            success: function (e) {
                let snackbar = new Snackbar();
                snackbar.exibirVerde(e);
            },
            error: function (e) {
                let snackbar = new Snackbar();
                snackbar.exibirVermelho(e, false);
            }
        });
    }

    mascara(e, m) {
        vanillaTextMask.maskInput({
            inputElement: e,
            mask: m,
        });
    }
}